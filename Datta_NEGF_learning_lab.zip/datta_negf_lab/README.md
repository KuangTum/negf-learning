# Datta NEGF learning laboratory

Start with **Datta_NEGF_workbook.ipynb**. It contains nine intentionally unfinished core functions, formulas, algorithms, three-point tests, and the full plotting/solver infrastructure. Keep **Datta_NEGF_reference.ipynb** closed until you need a worked solution or want to inspect the already-executed results.

## Files

- `Datta_NEGF_workbook.ipynb`: student edition, 81 cells, nine TODO functions, no fabricated execution outputs.
- `Datta_NEGF_reference.ipynb`: complete standalone reference; all 43 code cells were executed successfully. Contains the computed figures and actual test outputs.
- `Datta_NEGF_reference_readonly.html`: offline reading copy. Equations are pre-typeset SVG and figures are embedded. It is not an interactive notebook.
- `requirements.txt`: numerical dependencies, plus optional Pillow for GIF export.
- `datta_results/`: computed PNG panels, NPZ result arrays, and `validation_report.json`.

Both notebooks contain Markdown text with standard `$...$` and `$$...$$` mathematics and four embedded source-figure crops from the PDF you supplied. There is no runtime dependency on that PDF or on an external physics code.

## Running in VS Code

Use Python 3.10 or newer. Install the Python and Jupyter extensions, open the notebook, and select the Python kernel for your environment. From a terminal in the extracted folder:

```bash
python -m pip install -r requirements.txt
```

Run cells in order. The student notebook intentionally stops at the first unfinished function with a descriptive `NotImplementedError`. Each exercise has the necessary formula, an array-shape description, hints, and a checkpoint. The fully implemented reference can be run from top to bottom.

Do not disable assertions to force a plot to appear. A failed Poisson or probe solve raises an exception. Results are written to `datta_results` relative to the working directory. The default calculation is CPU-only; it limits BLAS to one thread because the matrices are small. Runtime and memory depend on your environment and on energy-grid refinement. The largest kernels retain selected Green-function columns rather than a dense Green matrix at every energy.

## Nine exercises

1. Spin- and transverse-mode-summed supply per area.
2. Finite-difference longitudinal Hamiltonian.
3. Retarded semi-infinite lead self-energy and branch selection.
4. Dense three-point retarded Green matrix.
5. Occupied correlation diagonal and nearest-neighbor components.
6. Bond-resolved current spectrum.
7. Poisson residual with eV units and zero-field faces.
8. Terminal current balance.
9. Analytic floating-probe Newton Jacobian.

## Source and honest reproduction status

The primary source is S. Datta, *Nanoscale device modeling: the Green’s function method*, Superlattices and Microstructures **28**, 253–278 (2000), DOI: 10.1006/spmi.2000.0920. Equation and page references are embedded throughout both notebooks. The source’s organization and phenomenological probe model are retained.

This is an **equation-based numerical reconstruction**, not a certified pixel-exact reproduction of every source figure. Original MATLAB code and numerical plot data were not supplied. Numerical choices not fully specified by the PDF are labeled explicitly, including temperature, chemical-potential calibration, quadrature, Poisson discretization, and the trial probe profile.

The reconstruction obtains an equilibrium central barrier of about **0.1153 eV** and coherent current density of **1.9054e12 A/m²** at 0.25 V, close to the visible scales of Figures 5 and 9.

The literal `Sigma_S^R = -i eta`, `Gamma_S = 2 eta` probe implementation with `eta=0.025 eV` and lower integration cutoff `-0.8 eV` gives a conserved scattering current of about **5.5433e11 A/m²**. This is below the approximately **9.5e11 A/m²** plateau visually estimated in Figure 12. This quantitative discrepancy remains unresolved. The notebook does not change eta to fit the published curve and does not claim that the missing source details prove a particular cause.

The notebook also derives an important model limitation: constant probe broadening combined with the unbounded transverse mode sum produces a logarithmically divergent density tail if the longitudinal energy integral is extended to minus infinity. Consequently a finite negative-energy cutoff is explicitly retained and varied. Refining the quadrature at fixed cutoff is a numerical test; moving this cutoff changes the regularized model. These two tests are reported separately.

## Validation

The reference passed the three-point algebra checks, correct retarded branch and positive spectral weight checks, uniform-chain unit-transmission test, analytic-versus-finite-difference probe Jacobian test, Poisson residual criteria, local continuity including trial probe injection, floating-probe current cancellation, coherent bond/contact consistency, quadrature refinement, and a gauge-shift check.

The executed default results have maximum Poisson residual below **1.6e-7 eV** and relative bond-current variation below **7e-10** in the coherent and conserving-probe cases. These validate the discrete implementation; they do not certify agreement with unpublished source numerical data.

All **336 Markdown math expressions** were additionally passed through a local MathJax typesetter without errors. An actual VS Code GUI session was not used in this environment; the notebook uses standard notebook/Markdown conventions rather than a custom renderer. The offline HTML provides an independent, pre-typeset reading view.

## Saving and extensions

The NPZ files contain numerical arrays and scalar metadata; they do not require pickle. `validation_report.json` records parameters, environment versions, numerical checks, and the cutoff study. The optional final notebook cell can export a GIF of the converged potential versus bias. That is a parameter sweep, not real-time wavepacket dynamics.

Do not identify the probe model with microscopic electron–phonon theory. It conserves each probe’s integrated particle current while permitting energy redistribution. A zero-current condition at every energy would instead be a different, elastic dephasing model.
